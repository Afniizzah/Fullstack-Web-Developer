import React, { useState } from 'react';
import { Navbar, NavbarBrand, Nav, NavItem, NavLink } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from './components/Home';
import Team from './components/Team';
import Contact from './components/Contact';

const App = () => {
  const [activePage, setActivePage] = useState('home');

  const renderPage = () => {
    switch (activePage) {
      case 'home':
        return <Home />;
      case 'team':
        return <Team />;
      case 'contact':
        return <Contact />;
      default:
        return <Home />;
    }
  };

  return (
    <>
      <Navbar color="light" light expand="md">
        <NavbarBrand href="#">MyApp</NavbarBrand>
        <Nav className="ms-auto" navbar>
          <NavItem>
            <NavLink href="#" onClick={() => setActivePage('home')}>Home</NavLink>
          </NavItem>
          <NavItem>
            <NavLink href="#" onClick={() => setActivePage('team')}>Team</NavLink>
          </NavItem>
          <NavItem>
            <NavLink href="#" onClick={() => setActivePage('contact')}>Contact</NavLink>
          </NavItem>
        </Nav>
      </Navbar>

      <div className="p-4">
        {renderPage()}
      </div>
    </>
  );
};

export default App;
