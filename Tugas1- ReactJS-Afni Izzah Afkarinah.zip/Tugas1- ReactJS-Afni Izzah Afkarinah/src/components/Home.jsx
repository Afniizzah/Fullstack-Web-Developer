import React from 'react';
import { Container, Row, Col } from 'reactstrap';

const Home = () => {
  return (
    <div
      className="py-5 min-vh-100"
      style={{ backgroundColor: '#3381c4' }} // ganti dengan warna yang kamu mau
    >
      <Container className="text-center">
        <Row className="justify-content-center mb-4">
          <Col md="8">
            <h1 className="display-4 fw-bold">Selamat Datang di Website Kami</h1>
            <p className="lead">Kami adalah tim kreatif yang antusias, berfokus pada pengembangan teknologi yang memudahkan kehidupan sehari-hari.</p>
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col md="8">
            <img
              src="https://i.pinimg.com/474x/83/74/78/83747898a06efde9e89086177ced4dd5.jpg"
              alt="Home Banner"
              className="img-fluid rounded shadow"
            />
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Home;