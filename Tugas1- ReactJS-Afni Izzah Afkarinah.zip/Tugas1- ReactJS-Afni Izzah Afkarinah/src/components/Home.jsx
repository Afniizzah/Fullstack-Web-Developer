// src/components/Home.jsx
import React from 'react';
import { Container, Row, Col } from 'reactstrap';

const Home = () => {
  return (
    <div className="bg-light py-5 min-vh-100">
      <Container className="text-center">
        <Row className="justify-content-center mb-4">
          <Col md="8">
            <h1 className="display-4 fw-bold">Selamat Datang di Website Kami</h1>
            <p className="lead">Kami adalah tim pengembang muda yang antusias dalam teknologi.</p>
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col md="8">
          <img
  src="https://cdn.pixabay.com/photo/2016/04/06/08/47/wire-rack-1311161_1280.jpg"
  alt="Home Banner"
  className="img-fluid rounded shadow"
/>

          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Home;
