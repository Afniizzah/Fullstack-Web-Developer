<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Ujian</title>
    <style>
       body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #87CEEB; /* Warna biru awan */
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    height: 100vh;
    color: white;
}


        .form-container {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 450px;
            text-align: center;
            flex: 1;
        }

        h2 {
            color: #000000;
            font-size: 30px;
            margin-bottom: 30px;
            font-weight: bold;
            letter-spacing: 2px;
        }

        label {
            font-size: 18px;
            color: #87CEEB;
            margin-bottom: 10px;
            text-align: left;
            display: block;
        }

        input[type="text"], input[type="email"], input[type="number"] {
            width: 100%;
            padding: 14px;
            margin: 12px 0;
            border: 2px solid #87CEEB;
            border-radius: 10px;
            font-size: 16px;
            color: #333;
            background-color: #FFFFFF;
            transition: border-color 0.3s ease-in-out;
        }

        input[type="text"]:focus, input[type="email"]:focus, input[type="number"]:focus {
            border-color: #f44336;
            outline: none;
        }

        input[type="submit"] {
            background-color: #87CEEB;
            color: white;
            padding: 15px;
            width: 100%;
            border-radius: 10px;
            font-size: 18px;
            cursor: pointer;
            border: none;
            margin-top: 20px;
            transition: background-color 0.3s ease-in-out;
        }

        input[type="submit"]:hover {
            background-color: #87CEEB;
        }

        .footer {
            font-size: 14px;
            color: #888;
            margin-top: 20px;
            text-align: center;
            width: 100%;
        }

        .footer a {
            color: #ff5722;
            text-decoration: none;
            font-weight: bold;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Ensure footer stays at the bottom */
        .footer {
            margin-top: auto;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Formulir Ujian</h2>
        <form action="proses.php" method="POST">
            <label for="nama">Nama:</label>
            <input type="text" id="nama" name="nama" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="nilai">Nilai Ujian:</label>
            <input type="number" id="nilai" name="nilai" required>

            <input type="submit" value="Kirim">
        </form>
    </div>

    <div class="footer">
        <p>Dengan mengirimkan formulir, Anda setuju dengan <a href="#">Kebijakan Privasi</a></p>
    </div>
</body>
</html>
