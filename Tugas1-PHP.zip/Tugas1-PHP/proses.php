<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $nilai = $_POST['nilai'];

    // Struktur kendali untuk menentukan kelulusan
    if ($nilai > 70) {
        $hasil = "Lulus";
        $statusColor = "#4CAF50"; // Hijau untuk Lulus
    } else {
        $hasil = "Remedial";
        $statusColor = "#F44336"; // Merah untuk Remedial
    }

    // Menampilkan hasil
    echo "
    <html lang='id'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Hasil Ujian</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background-color: #87CEEB;
                color: #333;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
            .result-container {
                background-color: #ffffff;
                padding: 40px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                width: 100%;
                max-width: 500px;
                text-align: center;
            }
            h2 {
                color: #333;
                font-size: 28px;
                margin-bottom: 20px;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            p {
                font-size: 18px;
                margin: 10px 0;
                line-height: 1.5;
            }
            .status {
                font-size: 20px;
                font-weight: bold;
                padding: 10px;
                border-radius: 10px;
                color: white;
                background-color: $statusColor;
                display: inline-block;
                margin-top: 20px;
            }
            .button {
                display: inline-block;
                background-color: #4CAF50;
                color: white;
                padding: 10px 20px;
                border-radius: 10px;
                text-decoration: none;
                margin-top: 30px;
                font-size: 18px;
                transition: background-color 0.3s;
            }
            .button:hover {
                background-color: #45a049;
            }
        </style>
    </head>
    <body>
        <div class='result-container'>
            <h2>Hasil Ujian</h2>
            <p><strong>Nama:</strong> $nama</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Nilai Ujian:</strong> $nilai</p>
            <p class='status'>$hasil</p>
            <a href='javascript:history.back()' class='button'>Kembali</a>
        </div>
    </body>
    </html>
    ";
}
?>
