import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Navbar, NavbarBrand, Nav, NavItem, NavLink } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from './components/Home';
import Team from './components/Team';
import Contact from './components/Contact';

const App = () => {
  return (
    <Router>
      <Navbar color="light" light expand="md">
        <NavbarBrand href="/">MyApp</NavbarBrand>
        <Nav className="ms-auto" navbar>
          {/* Navigasi Utama */}
          <NavItem>
            <NavLink tag={Link} to="/">Home</NavLink>
          </NavItem>

          {/* Navigasi Informasi */}
          <NavItem>
            <NavLink tag={Link} to="/team">Team</NavLink>
          </NavItem>

          {/* Navigasi Kontak */}
          <NavItem>
            <NavLink tag={Link} to="/contact">Contact</NavLink>
          </NavItem>
        </Nav>
      </Navbar>

      <Routes>
        {/* Halaman Utama */}
        <Route path="/" element={<Home />} />

        {/* Halaman Tim / Informasi */}
        <Route path="/team" element={<Team />} />

        {/* Halaman Kontak */}
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </Router>
  );
};

export default App;
