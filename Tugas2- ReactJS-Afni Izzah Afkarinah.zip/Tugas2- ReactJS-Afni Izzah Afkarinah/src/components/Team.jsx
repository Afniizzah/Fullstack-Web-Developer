// src/components/Team.jsx
import React from 'react';
import { Container, Row, Col, Card, CardImg, CardBody, CardTitle, CardText } from 'reactstrap';

const teamMembers = [
  {
    name: 'Rudi',
    role: 'Frontend Developer',
    image: 'https://i.pinimg.com/474x/1f/13/a6/1f13a634dd05cfb88f5e56e0f900058d.jpg',
    bio: 'Rudi berfokus pada pengembangan antarmuka yang responsif dan intuitif dengan React.'
  },
  {
    name: 'Naya',
    role: 'Backend Developer',
    image: 'https://i.pinimg.com/474x/0e/bd/b9/0ebdb9f8cb628dc5224bd2f84a2ff9e2.jpg',
    bio: 'Naya ahli dalam merancang dan mengelola API serta mengintegrasikan server dengan efisien.'
  },
  {
    name: 'Ayna',
    role: 'UI/UX Designer',
    image: 'https://i.pinimg.com/474x/22/eb/cb/22ebcbdbf8dbd2d0939b42e434c7ee5a.jpg',
    bio: 'Ayna berkomitmen untuk menciptakan antarmuka pengguna yang menarik dan fungsional.'
  }
];

const Team = () => {
  return (
    <Container className="py-5" style={{ backgroundColor: '#3381c4' }}>
      <h2 className="text-center mb-4" style={{ color: '#3381c40' }}>Our Team</h2>
      <Row>
        {teamMembers.map((member, index) => (
          <Col md="4" key={index} className="mb-4">
            <Card className="h-100 shadow-sm" style={{ backgroundColor: '#ffffff', borderColor: '#007bff' }}>
              <CardImg top src={member.image} alt={member.name} />
              <CardBody>
                <CardTitle tag="h5" style={{ color: '#007bff' }}>{member.name}</CardTitle>
                <CardText><strong>{member.role}</strong></CardText>
                <CardText>{member.bio}</CardText>
              </CardBody>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default Team;