import React, { useState } from 'react';
import Home from './components/Home';
import Book from './components/Book';

const App = () => {
  const [page, setPage] = useState('home');

  return (
    <div>
      <nav>
        <button onClick={() => setPage('home')}>Home</button>
        <button onClick={() => setPage('book')}>Book</button>
      </nav>

      <main>
      <div className="content-wrapper">
        {page === 'home' && <Home />}
        {page === 'book' && <Book />}
      </div>
      </main>
    </div>
  );

};

export default App;
