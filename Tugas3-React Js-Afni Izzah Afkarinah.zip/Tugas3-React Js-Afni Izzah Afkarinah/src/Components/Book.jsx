import React from 'react';
import books from '../utils/books';
import '../App.css'; // Pastikan ini ada jika styling diatur di App.css

const Book = () => {
  return (
    <div>
      <h2>Halaman Buku Lengkap</h2>
      {books.map(book => (
        <div
          key={book.id}
          style={{
            border: '1px solid #d865cb',
            padding: '10px',
            margin: '10px 0',
            display: 'flex',
            alignItems: 'flex-start',
            gap: '1rem',
            backgroundColor: 'white',
            borderRadius: '6px'
          }}
        >
          <img
            src={book.image}
            alt={book.title}
            style={{
              width: '100px',
              height: 'auto',
              borderRadius: '4px',
              objectFit: 'cover'
            }}
          />
          <div>
            <h3>{book.title}</h3>
            <p><strong>Penulis:</strong> {book.author}</p>
            <p><strong>Tahun:</strong> {book.year}</p>
            <p>{book.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Book;
