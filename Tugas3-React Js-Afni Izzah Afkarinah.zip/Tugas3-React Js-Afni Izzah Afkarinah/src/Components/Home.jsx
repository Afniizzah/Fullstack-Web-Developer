import React, { useState } from 'react';
import initialBooks from '../utils/books';

const Home = () => {
  const [books, setBooks] = useState(initialBooks);
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    year: '',
    description: '',
    image: ''
  });

  const handleChange = (e) => {
    setNewBook({
      ...newBook,
      [e.target.name]: e.target.value
    });
  };

  const handleAddBook = () => {
    const bookToAdd = {
      ...newBook,
      id: books.length + 1,
      year: parseInt(newBook.year)
    };
    setBooks([...books, bookToAdd]);
    setNewBook({
      title: '',
      author: '',
      year: '',
      description: '',
      image: ''
    });
  };

  return (
    <div>
      <h2>Halaman Home</h2>

      <div style={{ marginBottom: '2rem' }}>
        <h3>Tambah Buku Baru</h3>
        <input
          type="text"
          name="title"
          placeholder="Judul"
          value={newBook.title}
          onChange={handleChange}
        />
        <br />
        <input
          type="text"
          name="author"
          placeholder="Penulis"
          value={newBook.author}
          onChange={handleChange}
        />
        <br />
        <input
          type="number"
          name="year"
          placeholder="Tahun"
          value={newBook.year}
          onChange={handleChange}
        />
        <br />
        <textarea
          name="description"
          placeholder="Deskripsi"
          value={newBook.description}
          onChange={handleChange}
        />
        <br />
        <input
          type="text"
          name="image"
          placeholder="Link Gambar"
          value={newBook.image}
          onChange={handleChange}
        />
        <br />
        <button onClick={handleAddBook}>Tambah Buku</button>
      </div>

      {books.map((book) => (
        <div key={book.id} className="book-card">
          <img src={book.image} alt={book.title} />
          <div>
            <h3>{book.title}</h3>
            <p><strong>Penulis:</strong> {book.author}</p>
            <p><strong>Tahun:</strong> {book.year}</p>
            <p>{book.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Home;
