const books = [
    {
      id: 1,
      title: "Belajar JavaScript Dasar",
      author: "Andi Prasetyo",
      year: 2021,
      description: "Panduan lengkap untuk pemula yang ingin belajar JavaScript dari nol.",
      image: "https://kursus.onblajar.com/upload/kelas/2021-10/706e0b9a144fc0ac5f34e2848b507093.jpg"
    },
    {
      id: 2,
      title: "Mengenal Pemograman React JS",
      author: "Jubilee Enterprise",
      year: 2022,
      description: "Mengenal konsep dan praktik membuat aplikasi React modern.",
      image: "https://s3-ap-southeast-1.amazonaws.com/ebook-previews/40703/143597/1.jpg"
    },
    {
      id: 3,
      title: "Pemrograman Web Tingkat Lanjut",
      author: "Rohi abdulloh",
      year: 2020,
      description: "Membangun aplikasi web tingkat lanjut menggunakan Node.js dan React.",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2v6_cIXp3fSn5o_8fw97Wafj3G-SaZFw1fw&s"
    },
    {
      id: 4,
      title: "Pengantar Desain UI/UX",
      author: "Jubilee Enterprise",
      year: 2023,
      description: "Tips dan trik membuat antarmuka pengguna yang menarik dan intuitif.",
      image: "https://cdn.gramedia.com/uploads/products/xpv-70-6xn.jpg"
    },
    {
      id: 5,
      title: "Beginning Git and GitHub",
      author: "Mariot Tsitoara",
      year: 2021,
      description: "Menguasai version control dan kolaborasi proyek dengan GitHub.",
      image: "https://m.media-amazon.com/images/I/61esS2fofRL.jpg"
    },
    {
      id: 6,
      title: "Algoritma dan Struktur Data dengan C++",
      author: "Indra Yatini B, Erliansyah Nasution",
      year: 2019,
      description: "Dasar-dasar algoritma dan struktur data untuk pemrograman efisien.",
      image: "https://elibrary.bsi.ac.id/assets/images/buku/201270.jpeg"
    },
    {
      id: 7,
      title: "Machine Learning Dasar dan Praktis",
      author: "Eddy Suprihadi",
      year: 2022,
      description: "Perkenalan konsep machine learning dengan Python.",
      image: "https://images.tokopedia.net/img/cache/700/hDjmkQ/2023/1/14/4957c125-83dc-4d3d-9b07-db2f653b301a.jpg"
    },
    {
      id: 8,
      title: "Manajemen Database dengan MySQL",
      author: "Arbie",
      year: 2020,
      description: "Tutorial lengkap menggunakan MySQL untuk aplikasi web.",
      image: "https://lib.atim.ac.id/uploaded_files/sampul_koleksi/original/Monograf%20-%20Buku%20Teks,%20Buku%20Ajar/3669.jpg"
    },
    {
      id: 9,
      title: "Fullstack JavaScript Developer Express React",
      author: "Fika Ridaul Maulayya",
      year: 2024,
      description: "Menjadi fullstack developer menggunakan MERN stack.",
      image: "https://santrikoding.com/storage/courses/44ee6ddc-2929-403d-94d0-282e1515c68d.webp"
    }
  ];
  
  export default books;
  